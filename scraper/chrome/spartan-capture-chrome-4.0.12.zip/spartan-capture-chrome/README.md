# Spartan Universal Capture 4.0.12 (Chrome)

Same capture engine as the Tampermonkey 4.0.12 client.

Changed: captures now send only the game's `.game-content` area (plus the resource bar if it sits outside it) instead of the full page HTML. Falls back to the full page if `.game-content` is missing. `rawDomScope` in each capture records which was used.

Install: chrome://extensions -> Developer mode -> Load unpacked -> select this folder. Remove or disable the Tampermonkey version so pages aren't captured twice.
